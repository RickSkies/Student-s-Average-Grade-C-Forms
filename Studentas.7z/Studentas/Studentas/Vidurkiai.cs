﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Studentas
{
    public class Vidurkiai
    {
        public int v;
        public Vidurkiai(int v)
        {
            this.v = v;
        }

        public int GetVidurkis()
        {
            return v;
        }
    }
}
